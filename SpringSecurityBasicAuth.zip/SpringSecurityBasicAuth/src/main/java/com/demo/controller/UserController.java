package com.demo.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class UserController {
	
	@RequestMapping("/svc/v1/publicUser")
	public String getPublicUser(){
		return "This account is public. I am a Public User ";
	}

}
