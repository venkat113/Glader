package com.demo.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class UserController {
	
	@RequestMapping("/svc/v1/publicUser")
	public String getPublicUser(){
		return "This account is for Form auth -public. I am a Public User ";
	}

	
	@RequestMapping("/svc/v1/adminUser")
	public String getAdminUser(){
		return "This account is for Form auth -admin. I am an admin User ";
	}
}
